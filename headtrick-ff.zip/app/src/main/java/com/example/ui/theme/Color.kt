package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Futuristic Neon Free Fire HUD Palette
val NeonCyan = Color(0xFF00F0FF)
val NeonCyanDim = Color(0x3300F0FF)
val NeonOrange = Color(0xFFFF6B00)
val NeonOrangeDim = Color(0x33FF6B00)
val NeonGreen = Color(0xFF00FF66)
val NeonGreenDim = Color(0x3300FF66)
val NeonRed = Color(0xFFFF2A55)
val NeonYellow = Color(0xFFFFCC00)

val DarkCyberBg = Color(0xFF06090F)
val DarkGlassSurface = Color(0xD00A111E)
val DarkGlassSurfaceElevated = Color(0xE6101B2E)
val DarkGlassBorder = Color(0x4000F0FF)
val DarkGlassBorderOrange = Color(0x40FF6B00)

val InactiveGray = Color(0xFF424F60)
val InactiveTrack = Color(0xFF1E2632)
val TextBright = Color(0xFFF1F7FF)
val TextMuted = Color(0xFF7F92AA)
val TextCyan = Color(0xFF70E1FF)

