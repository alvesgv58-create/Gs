package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.Whatshot
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.DarkCyberBg
import com.example.ui.theme.DarkGlassBorder
import com.example.ui.theme.DarkGlassBorderOrange
import com.example.ui.theme.DarkGlassSurface
import com.example.ui.theme.DarkGlassSurfaceElevated
import com.example.ui.theme.InactiveGray
import com.example.ui.theme.InactiveTrack
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonCyanDim
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonGreenDim
import com.example.ui.theme.NeonOrange
import com.example.ui.theme.NeonOrangeDim
import com.example.ui.theme.NeonRed
import com.example.ui.theme.NeonYellow
import com.example.ui.theme.TextBright
import com.example.ui.theme.TextCyan
import com.example.ui.theme.TextMuted
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

// --- PARTICLE MODEL FOR ANIMATED BACKGROUND ---
data class Particle(
  var x: Float,
  var y: Float,
  var radius: Float,
  var speedY: Float,
  var speedX: Float,
  var alpha: Float,
  var color: Color
)

@Composable
fun AnimatedFreeFireBackground(
  modifier: Modifier = Modifier,
  content: @Composable () -> Unit
) {
  val infiniteTransition = rememberInfiniteTransition(label = "camera_and_particles")

  // Cinematic camera zoom & pan drift
  val cameraScale by infiniteTransition.animateFloat(
    initialValue = 1.05f,
    targetValue = 1.15f,
    animationSpec = infiniteRepeatable(
      animation = tween(durationMillis = 8000, easing = FastOutSlowInEasing),
      repeatMode = RepeatMode.Reverse
    ),
    label = "cameraScale"
  )

  val cameraPanX by infiniteTransition.animateFloat(
    initialValue = -12f,
    targetValue = 12f,
    animationSpec = infiniteRepeatable(
      animation = tween(durationMillis = 6500, easing = FastOutSlowInEasing),
      repeatMode = RepeatMode.Reverse
    ),
    label = "cameraPanX"
  )

  val pulseGlow by infiniteTransition.animateFloat(
    initialValue = 0.35f,
    targetValue = 0.75f,
    animationSpec = infiniteRepeatable(
      animation = tween(durationMillis = 2200, easing = LinearEasing),
      repeatMode = RepeatMode.Reverse
    ),
    label = "pulseGlow"
  )

  // Floating spark/ember particles
  val particles = remember {
    List(35) {
      Particle(
        x = Random.nextFloat(),
        y = Random.nextFloat(),
        radius = Random.nextFloat() * 3f + 1.5f,
        speedY = Random.nextFloat() * 0.003f + 0.0015f,
        speedX = (Random.nextFloat() - 0.5f) * 0.001f,
        alpha = Random.nextFloat() * 0.7f + 0.3f,
        color = when (Random.nextInt(4)) {
          0 -> NeonOrange
          1 -> NeonYellow
          2 -> NeonCyan
          else -> NeonRed
        }
      )
    }
  }

  val particleTicker by infiniteTransition.animateFloat(
    initialValue = 0f,
    targetValue = 1f,
    animationSpec = infiniteRepeatable(
      animation = tween(durationMillis = 3000, easing = LinearEasing),
      repeatMode = RepeatMode.Restart
    ),
    label = "particleTicker"
  )

  Box(modifier = modifier.fillMaxSize()) {
    // 1. Zoomed & Panning Battlefield Image with subtle motion blur
    Image(
      painter = painterResource(id = R.drawable.img_freefire_bg),
      contentDescription = "Cena de jogo Free Fire no mapa Bermuda",
      modifier = Modifier
        .fillMaxSize()
        .scale(cameraScale)
        .offset { IntOffset(cameraPanX.dp.roundToPx(), 0) },
      contentScale = ContentScale.Crop
    )

    // 2. High-Tech Tactical Grid & Scanline Canvas with Dynamic Floating Embers
    Canvas(modifier = Modifier.fillMaxSize()) {
      val canvasWidth = size.width
      val canvasHeight = size.height

      // Subtle dark vignette to ensure readability
      drawRect(
        brush = Brush.verticalGradient(
          colors = listOf(
            Color(0xB3040810),
            Color(0x99060B14),
            Color(0xCC03060C)
          )
        )
      )

      // Cyber Grid Lines
      val gridSpacing = 48.dp.toPx()
      var x = 0f
      while (x < canvasWidth) {
        drawLine(
          color = NeonCyan.copy(alpha = 0.04f),
          start = Offset(x, 0f),
          end = Offset(x, canvasHeight),
          strokeWidth = 1f
        )
        x += gridSpacing
      }

      var y = 0f
      while (y < canvasHeight) {
        drawLine(
          color = NeonCyan.copy(alpha = 0.04f),
          start = Offset(0f, y),
          end = Offset(canvasWidth, y),
          strokeWidth = 1f
        )
        y += gridSpacing
      }

      // Render Floating Embers / Sparks
      particles.forEach { p ->
        p.y -= p.speedY
        p.x += p.speedX
        if (p.y < 0f) {
          p.y = 1f
          p.x = Random.nextFloat()
        }
        if (p.x < 0f) p.x = 1f
        if (p.x > 1f) p.x = 0f

        val px = p.x * canvasWidth
        val py = p.y * canvasHeight

        // Glow halo
        drawCircle(
          color = p.color.copy(alpha = (p.alpha * pulseGlow * 0.4f).coerceIn(0f, 1f)),
          radius = p.radius * 2.5f,
          center = Offset(px, py)
        )
        // Core particle
        drawCircle(
          color = p.color.copy(alpha = p.alpha),
          radius = p.radius,
          center = Offset(px, py)
        )
      }
    }

    // 3. Child HUD Overlay Content
    content()
  }
}

// --- HIGH-VISIBILITY LUMINOUS ON/OFF TOGGLE SWITCH ---
@Composable
fun CyberSwitch(
  checked: Boolean,
  onCheckedChange: (Boolean) -> Unit,
  modifier: Modifier = Modifier,
  enabled: Boolean = true
) {
  val switchWidth = 76.dp
  val switchHeight = 36.dp
  val thumbSize = 26.dp
  val thumbPadding = 5.dp

  // Thumb position
  val thumbOffset by animateDpAsState(
    targetValue = if (checked) switchWidth - thumbSize - thumbPadding else thumbPadding,
    animationSpec = tween(durationMillis = 200, easing = FastOutSlowInEasing),
    label = "thumbOffset"
  )

  // Track colors
  val trackBorderColor by animateColorAsState(
    targetValue = if (checked) NeonGreen else InactiveGray,
    animationSpec = tween(durationMillis = 200),
    label = "trackBorderColor"
  )

  val trackBgBrush = if (checked) {
    Brush.horizontalGradient(
      colors = listOf(
        Color(0xFF003816),
        Color(0xFF005220)
      )
    )
  } else {
    Brush.horizontalGradient(
      colors = listOf(
        Color(0xFF141922),
        Color(0xFF1A222E)
      )
    )
  }

  val labelColor by animateColorAsState(
    targetValue = if (checked) NeonGreen else TextMuted,
    animationSpec = tween(durationMillis = 200),
    label = "labelColor"
  )

  Box(
    modifier = modifier
      .size(width = switchWidth, height = switchHeight)
      .clip(RoundedCornerShape(18.dp))
      .border(
        width = if (checked) 2.dp else 1.dp,
        color = trackBorderColor,
        shape = RoundedCornerShape(18.dp)
      )
      .background(trackBgBrush)
      .clickable(
        interactionSource = remember { MutableInteractionSource() },
        indication = null,
        enabled = enabled
      ) {
        onCheckedChange(!checked)
      }
      .testTag("cyber_switch_${if (checked) "on" else "off"}"),
    contentAlignment = Alignment.CenterStart
  ) {
    // Label behind thumb (ON on left when checked, OFF on right when unchecked)
    Row(
      modifier = Modifier
        .fillMaxSize()
        .padding(horizontal = 9.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = if (checked) Arrangement.Start else Arrangement.End
    ) {
      if (checked) {
        Text(
          text = "ON",
          color = NeonGreen,
          fontSize = 11.sp,
          fontWeight = FontWeight.Black,
          fontFamily = FontFamily.Monospace,
          letterSpacing = 0.5.sp
        )
      } else {
        Text(
          text = "OFF",
          color = InactiveGray,
          fontSize = 11.sp,
          fontWeight = FontWeight.Bold,
          fontFamily = FontFamily.Monospace,
          letterSpacing = 0.5.sp
        )
      }
    }

    // Sliding Thumb
    Box(
      modifier = Modifier
        .offset(x = thumbOffset)
        .size(thumbSize)
        .shadow(
          elevation = if (checked) 8.dp else 2.dp,
          shape = CircleShape,
          spotColor = if (checked) NeonGreen else Color.Black
        )
        .clip(CircleShape)
        .background(
          if (checked) {
            Brush.radialGradient(
              colors = listOf(Color.White, NeonGreen, Color(0xFF00CC52))
            )
          } else {
            Brush.radialGradient(
              colors = listOf(Color(0xFF8C9BAE), Color(0xFF485669))
            )
          }
        )
        .border(
          width = 1.dp,
          color = if (checked) Color.White.copy(alpha = 0.8f) else InactiveGray,
          shape = CircleShape
        )
    )
  }
}

// --- ROTATING PRECISION CROSSHAIR RETICLE ---
@Composable
fun PrecisionCrosshairIcon(
  modifier: Modifier = Modifier,
  color: Color = NeonCyan,
  sizeDp: Dp = 32.dp
) {
  val infiniteTransition = rememberInfiniteTransition(label = "reticle_rot")
  val rotation by infiniteTransition.animateFloat(
    initialValue = 0f,
    targetValue = 360f,
    animationSpec = infiniteRepeatable(
      animation = tween(durationMillis = 9000, easing = LinearEasing),
      repeatMode = RepeatMode.Restart
    ),
    label = "rotation"
  )

  val pulseScale by infiniteTransition.animateFloat(
    initialValue = 0.95f,
    targetValue = 1.05f,
    animationSpec = infiniteRepeatable(
      animation = tween(durationMillis = 1400, easing = FastOutSlowInEasing),
      repeatMode = RepeatMode.Reverse
    ),
    label = "pulseScale"
  )

  Canvas(
    modifier = modifier
      .size(sizeDp)
      .scale(pulseScale)
  ) {
    val center = Offset(size.width / 2f, size.height / 2f)
    val outerRadius = size.width * 0.44f
    val innerRadius = size.width * 0.22f

    // Outer segmented rotating ring
    rotate(rotation, pivot = center) {
      drawCircle(
        color = color.copy(alpha = 0.35f),
        radius = outerRadius,
        center = center,
        style = Stroke(
          width = 1.5f,
          pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f)
        )
      )

      // 4 corner ticks
      for (i in 0 until 4) {
        val angle = Math.toRadians((i * 90.0))
        val startX = center.x + (outerRadius - 4f) * cos(angle).toFloat()
        val startY = center.y + (outerRadius - 4f) * sin(angle).toFloat()
        val endX = center.x + (outerRadius + 4f) * cos(angle).toFloat()
        val endY = center.y + (outerRadius + 4f) * sin(angle).toFloat()
        drawLine(
          color = color,
          start = Offset(startX, startY),
          end = Offset(endX, endY),
          strokeWidth = 2f
        )
      }
    }

    // Inner circle
    drawCircle(
      color = color.copy(alpha = 0.8f),
      radius = innerRadius,
      center = center,
      style = Stroke(width = 1.5f)
    )

    // Center targeting cross lines
    drawLine(
      color = NeonOrange,
      start = Offset(center.x - 6f, center.y),
      end = Offset(center.x + 6f, center.y),
      strokeWidth = 2f
    )
    drawLine(
      color = NeonOrange,
      start = Offset(center.x, center.y - 6f),
      end = Offset(center.x, center.y + 6f),
      strokeWidth = 2f
    )

    // Red center point
    drawCircle(
      color = NeonRed,
      radius = 2.5f,
      center = center
    )
  }
}

// --- CYBER BRACKET CORNERS DECORATION ---
fun Modifier.cyberCorners(
  color: Color = NeonCyan,
  bracketLength: Dp = 12.dp,
  strokeWidthDp: Dp = 1.5.dp
): Modifier = this.drawBehind {
  val bLen = bracketLength.toPx()
  val sWidth = strokeWidthDp.toPx()
  val w = size.width
  val h = size.height

  // Top-Left
  drawLine(color, Offset(0f, 0f), Offset(bLen, 0f), sWidth)
  drawLine(color, Offset(0f, 0f), Offset(0f, bLen), sWidth)

  // Top-Right
  drawLine(color, Offset(w, 0f), Offset(w - bLen, 0f), sWidth)
  drawLine(color, Offset(w, 0f), Offset(w, bLen), sWidth)

  // Bottom-Left
  drawLine(color, Offset(0f, h), Offset(bLen, h), sWidth)
  drawLine(color, Offset(0f, h), Offset(0f, h - bLen), sWidth)

  // Bottom-Right
  drawLine(color, Offset(w, h), Offset(w - bLen, h), sWidth)
  drawLine(color, Offset(w, h), Offset(w, h - bLen), sWidth)
}
