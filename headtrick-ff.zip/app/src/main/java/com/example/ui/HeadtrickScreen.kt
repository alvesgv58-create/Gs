package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.GpsFixed
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.Whatshot
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.AnimatedFreeFireBackground
import com.example.ui.components.CyberSwitch
import com.example.ui.components.PrecisionCrosshairIcon
import com.example.ui.components.cyberCorners
import com.example.ui.theme.DarkCyberBg
import com.example.ui.theme.DarkGlassBorder
import com.example.ui.theme.DarkGlassBorderOrange
import com.example.ui.theme.DarkGlassSurface
import com.example.ui.theme.DarkGlassSurfaceElevated
import com.example.ui.theme.InactiveGray
import com.example.ui.theme.InactiveTrack
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonCyanDim
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonGreenDim
import com.example.ui.theme.NeonOrange
import com.example.ui.theme.NeonOrangeDim
import com.example.ui.theme.NeonRed
import com.example.ui.theme.NeonYellow
import com.example.ui.theme.TextBright
import com.example.ui.theme.TextCyan
import com.example.ui.theme.TextMuted
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

// Command Item Model
data class CommandItem(
  val id: Int,
  val title: String,
  val subtext: String,
  val icon: ImageVector,
  var isEnabled: Boolean,
  val defaultVal: Float = 1.0f
)

@Composable
fun HeadtrickScreen() {
  val coroutineScope = rememberCoroutineScope()

  // 5 Commands specified by prompt
  val commands = remember {
    mutableStateListOf(
      CommandItem(
        id = 1,
        title = "AIMBOT // HEADSHOT",
        subtext = "PRECISÃO ABSOLUTA • TRAVA EM CABEÇA • FOV 360°",
        icon = Icons.Filled.MyLocation,
        isEnabled = true
      ),
      CommandItem(
        id = 2,
        title = "ESP // WALLHACK",
        subtext = "VISÃO DE CONTORNO RAY-X • SKELETON • LINHAS 3D",
        icon = Icons.Filled.Visibility,
        isEnabled = true
      ),
      CommandItem(
        id = 3,
        title = "NO RECOIL // STABILIZER",
        subtext = "ESTABILIZADOR DE TIRO • RECUO ZERO 100% ATIVO",
        icon = Icons.Filled.Tune,
        isEnabled = true
      ),
      CommandItem(
        id = 4,
        title = "RAPID FIRE // TURBO",
        subtext = "CADÊNCIA ACELERADA • TAXA DE DISPARO TURBO x2",
        icon = Icons.Filled.Bolt,
        isEnabled = true
      ),
      CommandItem(
        id = 5,
        title = "AUTO LOOT",
        subtext = "COLETA AUTOMÁTICA DE MOCHILAS, ARMAS E COLETES",
        icon = Icons.Filled.Inventory2,
        isEnabled = false
      )
    )
  }

  // Headshots Counter (Prompt: 'HEADSHOTS // 14' - destaque)
  var headshotCount by remember { mutableIntStateOf(14) }
  var showCritFeedback by remember { mutableStateOf(false) }

  // Server Status Bar Ping simulation ('ONLINE // PING: 12ms')
  var currentPing by remember { mutableIntStateOf(12) }
  LaunchedEffect(Unit) {
    while (true) {
      delay(3500)
      currentPing = (11..14).random()
    }
  }

  // Apply Settings State
  var isApplying by remember { mutableStateOf(false) }
  var applyProgress by remember { mutableFloatStateOf(0f) }
  var showSuccessBanner by remember { mutableStateOf(false) }

  fun onApplySettings() {
    if (isApplying) return
    coroutineScope.launch {
      isApplying = true
      applyProgress = 0f
      showSuccessBanner = false
      val steps = 20
      for (i in 1..steps) {
        delay(60)
        applyProgress = i / steps.toFloat()
      }
      isApplying = false
      showSuccessBanner = true
      delay(4500)
      showSuccessBanner = false
    }
  }

  // Background with Battlefield and Floating Embers
  AnimatedFreeFireBackground {
    Box(
      modifier = Modifier
        .fillMaxSize()
        .windowInsetsPadding(WindowInsets.statusBars)
        .windowInsetsPadding(WindowInsets.navigationBars),
      contentAlignment = Alignment.TopCenter
    ) {
      Column(
        modifier = Modifier
          .fillMaxSize()
          .widthIn(max = 680.dp)
          .verticalScroll(rememberScrollState())
          .padding(horizontal = 16.dp, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
      ) {
        // --- 1. HEADER: 'HEADTRICK // FREE FIRE' + LOGO + PRECISION CROSSHAIR ---
        HUDHeaderSection()

        Spacer(modifier = Modifier.height(14.dp))

        // --- 2. SERVER STATUS BAR + HEADSHOTS COUNTER CARD ---
        HUDStatusAndCounterRow(
          pingMs = currentPing,
          headshots = headshotCount,
          showCrit = showCritFeedback,
          onTestHeadshot = {
            headshotCount += 1
            showCritFeedback = true
            coroutineScope.launch {
              delay(1200)
              showCritFeedback = false
            }
          }
        )

        Spacer(modifier = Modifier.height(16.dp))

        // --- 3. CONTROL SECTION: 5 NUMBERED COMMANDS WITH ON/OFF TOGGLES ---
        HUDControlSection(
          commands = commands,
          onToggleCommand = { index, newState ->
            commands[index] = commands[index].copy(isEnabled = newState)
          }
        )

        Spacer(modifier = Modifier.height(20.dp))

        // --- 4. APPLY SETTINGS BUTTON & PROGRESS ---
        HUDApplySettingsSection(
          isApplying = isApplying,
          progress = applyProgress,
          showSuccess = showSuccessBanner,
          onApply = { onApplySettings() }
        )

        Spacer(modifier = Modifier.height(24.dp))
      }
    }
  }
}

// --- HEADER COMPONENT ---
@Composable
private fun HUDHeaderSection() {
  val infiniteTransition = rememberInfiniteTransition(label = "badgeGlow")
  val pulseGlow by infiniteTransition.animateFloat(
    initialValue = 0.7f,
    targetValue = 1f,
    animationSpec = infiniteRepeatable(
      animation = tween(1500, easing = LinearEasing),
      repeatMode = RepeatMode.Reverse
    ),
    label = "pulseGlow"
  )

  Surface(
    modifier = Modifier
      .fillMaxWidth()
      .cyberCorners(color = NeonCyan, bracketLength = 14.dp)
      .clip(CutCornerShape(topStart = 10.dp, bottomEnd = 10.dp))
      .border(
        width = 1.dp,
        brush = Brush.horizontalGradient(
          colors = listOf(NeonCyan, NeonOrange, NeonCyan)
        ),
        shape = CutCornerShape(topStart = 10.dp, bottomEnd = 10.dp)
      ),
    color = DarkGlassSurfaceElevated
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 14.dp),
      horizontalAlignment = Alignment.CenterHorizontally
    ) {
      // Top Subtitle & Protocol Badge
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Box(
            modifier = Modifier
              .size(8.dp)
              .clip(CircleShape)
              .background(NeonGreen)
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = "TAC-OS // FREE FIRE SYSTEM OVERLAY",
            color = TextCyan,
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace,
            letterSpacing = 1.sp
          )
        }

        // 16:9 Bermuda Badge
        Box(
          modifier = Modifier
            .clip(RoundedCornerShape(4.dp))
            .background(NeonOrangeDim)
            .border(0.8.dp, NeonOrange, RoundedCornerShape(4.dp))
            .padding(horizontal = 6.dp, vertical = 2.dp)
        ) {
          Text(
            text = "MAP: BERMUDA",
            color = NeonOrange,
            fontSize = 9.sp,
            fontWeight = FontWeight.Black,
            fontFamily = FontFamily.Monospace
          )
        }
      }

      Spacer(modifier = Modifier.height(10.dp))

      // Main Header with Title & Precision Crosshairs
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
      ) {
        // Precision Crosshair Icon (Left)
        PrecisionCrosshairIcon(
          modifier = Modifier.padding(end = 10.dp),
          color = NeonCyan,
          sizeDp = 34.dp
        )

        // Title: 'HEADTRICK // FREE FIRE'
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
              text = "HEADTRICK",
              color = TextBright,
              fontSize = 24.sp,
              fontWeight = FontWeight.Black,
              fontFamily = FontFamily.Monospace,
              letterSpacing = 2.sp
            )
            Text(
              text = " // ",
              color = NeonOrange,
              fontSize = 22.sp,
              fontWeight = FontWeight.Black,
              fontFamily = FontFamily.Monospace
            )
            Text(
              text = "FREE FIRE",
              color = NeonCyan,
              fontSize = 24.sp,
              fontWeight = FontWeight.Black,
              fontFamily = FontFamily.Monospace,
              letterSpacing = 2.sp
            )
          }

          // Stylized Free Fire emblem tag
          Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(top = 2.dp)
          ) {
            Icon(
              imageVector = Icons.Filled.Whatshot,
              contentDescription = "Free Fire Logo Emblem",
              tint = NeonOrange,
              modifier = Modifier.size(14.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
              text = "BATTLE ROYALE • PRO AIM MATRIX v4.2",
              color = TextMuted,
              fontSize = 10.sp,
              fontWeight = FontWeight.SemiBold,
              fontFamily = FontFamily.Monospace,
              letterSpacing = 1.sp
            )
          }
        }

        // Precision Crosshair Icon (Right)
        PrecisionCrosshairIcon(
          modifier = Modifier.padding(start = 10.dp),
          color = NeonOrange,
          sizeDp = 34.dp
        )
      }
    }
  }
}

// --- STATUS BAR + HEADSHOT COUNTER SECTION ---
@Composable
private fun HUDStatusAndCounterRow(
  pingMs: Int,
  headshots: Int,
  showCrit: Boolean,
  onTestHeadshot: () -> Unit
) {
  val infiniteTransition = rememberInfiniteTransition(label = "pulsePing")
  val pingAlpha by infiniteTransition.animateFloat(
    initialValue = 0.4f,
    targetValue = 1f,
    animationSpec = infiniteRepeatable(
      animation = tween(800, easing = LinearEasing),
      repeatMode = RepeatMode.Reverse
    ),
    label = "pingAlpha"
  )

  Row(
    modifier = Modifier.fillMaxWidth(),
    horizontalArrangement = Arrangement.spacedBy(10.dp)
  ) {
    // 1. Server Status Bar: 'ONLINE // PING: 12ms'
    Card(
      modifier = Modifier
        .weight(1.1f)
        .border(1.dp, DarkGlassBorder, RoundedCornerShape(8.dp)),
      colors = CardDefaults.cardColors(containerColor = DarkGlassSurface),
      shape = RoundedCornerShape(8.dp)
    ) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 12.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Column {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
              modifier = Modifier
                .size(10.dp)
                .clip(CircleShape)
                .background(NeonGreen.copy(alpha = pingAlpha))
                .border(1.dp, NeonGreen, CircleShape)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = "SERVER STATUS",
              color = TextMuted,
              fontSize = 9.sp,
              fontWeight = FontWeight.Bold,
              fontFamily = FontFamily.Monospace
            )
          }
          Spacer(modifier = Modifier.height(4.dp))
          Text(
            text = "ONLINE // PING: ${pingMs}ms",
            color = NeonGreen,
            fontSize = 13.sp,
            fontWeight = FontWeight.Black,
            fontFamily = FontFamily.Monospace,
            letterSpacing = 0.5.sp
          )
        }

        Box(
          modifier = Modifier
            .size(32.dp)
            .clip(CircleShape)
            .background(NeonGreenDim)
            .border(1.dp, NeonGreen.copy(alpha = 0.4f), CircleShape),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            imageVector = Icons.Filled.CloudDone,
            contentDescription = "Server Online",
            tint = NeonGreen,
            modifier = Modifier.size(18.dp)
          )
        }
      }
    }

    // 2. Headshots Counter Card: 'HEADSHOTS // 14' (Destaque)
    Card(
      modifier = Modifier
        .weight(1.3f)
        .border(1.5.dp, DarkGlassBorderOrange, RoundedCornerShape(8.dp))
        .clickable(
          interactionSource = remember { MutableInteractionSource() },
          indication = null
        ) {
          onTestHeadshot()
        }
        .testTag("headshots_counter_card"),
      colors = CardDefaults.cardColors(
        containerColor = DarkGlassSurfaceElevated
      ),
      shape = RoundedCornerShape(8.dp)
    ) {
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .background(
            Brush.linearGradient(
              colors = listOf(
                NeonOrangeDim.copy(alpha = 0.2f),
                Color.Transparent
              )
            )
          )
          .padding(horizontal = 12.dp, vertical = 10.dp)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(
                imageVector = Icons.Filled.LocalFireDepartment,
                contentDescription = null,
                tint = NeonOrange,
                modifier = Modifier.size(13.dp)
              )
              Spacer(modifier = Modifier.width(4.dp))
              Text(
                text = "KILL MATRIX",
                color = NeonOrange,
                fontSize = 9.sp,
                fontWeight = FontWeight.Black,
                fontFamily = FontFamily.Monospace,
                letterSpacing = 0.5.sp
              )
            }
            Spacer(modifier = Modifier.height(2.dp))
            Row(verticalAlignment = Alignment.Bottom) {
              Text(
                text = "HEADSHOTS // ",
                color = TextBright,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
              )
              Text(
                text = "$headshots",
                color = NeonOrange,
                fontSize = 18.sp,
                fontWeight = FontWeight.Black,
                fontFamily = FontFamily.Monospace
              )
            }
            Text(
              text = "TAXA CRÍTICA: 98.6%",
              color = TextCyan,
              fontSize = 9.sp,
              fontWeight = FontWeight.SemiBold,
              fontFamily = FontFamily.Monospace
            )
          }

          // Interactive "+1 TEST" button
          Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
              modifier = Modifier
                .clip(RoundedCornerShape(6.dp))
                .background(NeonOrange)
                .padding(horizontal = 7.dp, vertical = 5.dp)
            ) {
              Text(
                text = "+1 HIT",
                color = DarkCyberBg,
                fontSize = 10.sp,
                fontWeight = FontWeight.Black,
                fontFamily = FontFamily.Monospace
              )
            }
            if (showCrit) {
              Text(
                text = "CRIT!",
                color = NeonRed,
                fontSize = 9.sp,
                fontWeight = FontWeight.Black,
                fontFamily = FontFamily.Monospace,
                modifier = Modifier.padding(top = 2.dp)
              )
            }
          }
        }
      }
    }
  }
}

// --- CONTROL SECTION: LIST OF 5 COMMANDS WITH ON/OFF TOGGLES ---
@Composable
private fun HUDControlSection(
  commands: List<CommandItem>,
  onToggleCommand: (Int, Boolean) -> Unit
) {
  Column(modifier = Modifier.fillMaxWidth()) {
    // Section Header
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 4.dp, vertical = 6.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
          modifier = Modifier
            .width(4.dp)
            .height(14.dp)
            .background(NeonCyan)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
          text = "SEÇÃO DE CONTROLE // HEADTRICK PROTOCOLS",
          color = TextBright,
          fontSize = 12.sp,
          fontWeight = FontWeight.Black,
          fontFamily = FontFamily.Monospace,
          letterSpacing = 1.sp
        )
      }

      Text(
        text = "ACTIVE: ${commands.count { it.isEnabled }}/5",
        color = NeonGreen,
        fontSize = 11.sp,
        fontWeight = FontWeight.Bold,
        fontFamily = FontFamily.Monospace
      )
    }

    Spacer(modifier = Modifier.height(6.dp))

    // List of 5 Command Cards
    commands.forEachIndexed { index, item ->
      HUDCommandCard(
        item = item,
        onToggle = { newState ->
          onToggleCommand(index, newState)
        }
      )
      if (index < commands.lastIndex) {
        Spacer(modifier = Modifier.height(10.dp))
      }
    }
  }
}

// --- INDIVIDUAL COMMAND CARD WITH METALLIC BORDER, NEON ICON & GLOWING TOGGLE ---
@Composable
private fun HUDCommandCard(
  item: CommandItem,
  onToggle: (Boolean) -> Unit
) {
  val isChecked = item.isEnabled

  val borderColor by animateColorAsState(
    targetValue = if (isChecked) NeonCyan.copy(alpha = 0.7f) else DarkGlassBorder.copy(alpha = 0.25f),
    animationSpec = tween(250),
    label = "cardBorderColor"
  )

  val iconColor by animateColorAsState(
    targetValue = if (isChecked) NeonGreen else InactiveGray,
    animationSpec = tween(250),
    label = "cardIconColor"
  )

  val iconBgColor by animateColorAsState(
    targetValue = if (isChecked) NeonGreenDim else Color(0x261E2734),
    animationSpec = tween(250),
    label = "cardIconBgColor"
  )

  Card(
    modifier = Modifier
      .fillMaxWidth()
      .border(
        width = if (isChecked) 1.2.dp else 1.dp,
        color = borderColor,
        shape = RoundedCornerShape(10.dp)
      )
      .testTag("command_card_${item.id}"),
    colors = CardDefaults.cardColors(
      containerColor = if (isChecked) DarkGlassSurfaceElevated else DarkGlassSurface
    ),
    shape = RoundedCornerShape(10.dp)
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .background(
          if (isChecked) {
            Brush.horizontalGradient(
              colors = listOf(
                NeonCyanDim.copy(alpha = 0.12f),
                Color.Transparent,
                NeonGreenDim.copy(alpha = 0.08f)
              )
            )
          } else {
            Brush.horizontalGradient(
              colors = listOf(Color.Transparent, Color.Transparent)
            )
          }
        )
        .padding(horizontal = 14.dp, vertical = 12.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      // Left: Number Badge + Icon + Title & Description
      Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.weight(1f)
      ) {
        // Number badge (1 to 5)
        Box(
          modifier = Modifier
            .size(26.dp)
            .clip(RoundedCornerShape(6.dp))
            .background(if (isChecked) NeonCyanDim else InactiveTrack)
            .border(
              width = 1.dp,
              color = if (isChecked) NeonCyan else InactiveGray,
              shape = RoundedCornerShape(6.dp)
            ),
          contentAlignment = Alignment.Center
        ) {
          Text(
            text = "0${item.id}",
            color = if (isChecked) NeonCyan else TextMuted,
            fontSize = 11.sp,
            fontWeight = FontWeight.Black,
            fontFamily = FontFamily.Monospace
          )
        }

        Spacer(modifier = Modifier.width(10.dp))

        // Command Icon
        Box(
          modifier = Modifier
            .size(38.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(iconBgColor)
            .border(
              width = 1.dp,
              color = if (isChecked) NeonGreen.copy(alpha = 0.5f) else Color(0x33445566),
              shape = RoundedCornerShape(8.dp)
            ),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            imageVector = item.icon,
            contentDescription = item.title,
            tint = iconColor,
            modifier = Modifier.size(22.dp)
          )
        }

        Spacer(modifier = Modifier.width(12.dp))

        // Titles
        Column(modifier = Modifier.padding(end = 8.dp)) {
          Text(
            text = "${item.id}. ${item.title}",
            color = if (isChecked) TextBright else TextMuted,
            fontSize = 13.sp,
            fontWeight = FontWeight.Black,
            fontFamily = FontFamily.Monospace,
            letterSpacing = 0.5.sp
          )
          Spacer(modifier = Modifier.height(2.dp))
          Text(
            text = item.subtext,
            color = if (isChecked) TextCyan else InactiveGray,
            fontSize = 9.sp,
            fontWeight = FontWeight.Normal,
            fontFamily = FontFamily.Monospace,
            lineHeight = 12.sp
          )
        }
      }

      // Right: High-Visibility Luminous ON/OFF Switch
      CyberSwitch(
        checked = isChecked,
        onCheckedChange = { newState ->
          onToggle(newState)
        }
      )
    }
  }
}

// --- APPLY SETTINGS BUTTON & CONFIRMATION HUD ---
@Composable
private fun HUDApplySettingsSection(
  isApplying: Boolean,
  progress: Float,
  showSuccess: Boolean,
  onApply: () -> Unit
) {
  Column(
    modifier = Modifier.fillMaxWidth(),
    horizontalAlignment = Alignment.CenterHorizontally
  ) {
    // Injection Progress Bar
    if (isApplying) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(bottom = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Text(
            text = "INJETANDO PROTOCOLOS NO FREE FIRE...",
            color = NeonCyan,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace
          )
          Text(
            text = "${(progress * 100).toInt()}%",
            color = NeonGreen,
            fontSize = 10.sp,
            fontWeight = FontWeight.Black,
            fontFamily = FontFamily.Monospace
          )
        }
        Spacer(modifier = Modifier.height(6.dp))
        LinearProgressIndicator(
          progress = { progress },
          modifier = Modifier
            .fillMaxWidth()
            .height(6.dp)
            .clip(RoundedCornerShape(3.dp)),
          color = NeonGreen,
          trackColor = InactiveTrack,
          strokeCap = StrokeCap.Round
        )
      }
    }

    // Success HUD Alert Banner
    AnimatedVisibility(
      visible = showSuccess,
      enter = fadeIn() + slideInVertically(),
      exit = fadeOut() + slideOutVertically()
    ) {
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .padding(bottom = 12.dp)
          .clip(RoundedCornerShape(8.dp))
          .background(Color(0xE6052E14))
          .border(1.5.dp, NeonGreen, RoundedCornerShape(8.dp))
          .padding(horizontal = 14.dp, vertical = 10.dp)
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier.fillMaxWidth()
        ) {
          Icon(
            imageVector = Icons.Filled.CheckCircle,
            contentDescription = "Success",
            tint = NeonGreen,
            modifier = Modifier.size(20.dp)
          )
          Spacer(modifier = Modifier.width(10.dp))
          Column {
            Text(
              text = "[✓] CONFIGURAÇÕES APLICADAS COM SUCESSO!",
              color = NeonGreen,
              fontSize = 11.sp,
              fontWeight = FontWeight.Black,
              fontFamily = FontFamily.Monospace
            )
            Text(
              text = "SINCRONIZADO COM O SERVIDOR // LATÊNCIA OTIMIZADA",
              color = TextBright,
              fontSize = 9.sp,
              fontFamily = FontFamily.Monospace
            )
          }
        }
      }
    }

    // High-Tech 'APLICAR CONFIGURAÇÕES' Button
    Box(
      modifier = Modifier
        .fillMaxWidth()
        .height(54.dp)
        .shadow(
          elevation = 12.dp,
          shape = CutCornerShape(topStart = 12.dp, bottomEnd = 12.dp),
          spotColor = NeonCyan
        )
        .clip(CutCornerShape(topStart = 12.dp, bottomEnd = 12.dp))
        .background(
          Brush.horizontalGradient(
            colors = listOf(
              Color(0xFF008DA5),
              NeonCyan,
              NeonOrange
            )
          )
        )
        .border(
          width = 1.5.dp,
          brush = Brush.horizontalGradient(
            colors = listOf(NeonCyan, Color.White, NeonOrange)
          ),
          shape = CutCornerShape(topStart = 12.dp, bottomEnd = 12.dp)
        )
        .clickable(
          enabled = !isApplying,
          onClick = onApply
        )
        .testTag("apply_settings_button"),
      contentAlignment = Alignment.Center
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
      ) {
        Icon(
          imageVector = Icons.Filled.FlashOn,
          contentDescription = null,
          tint = DarkCyberBg,
          modifier = Modifier.size(22.dp)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
          text = if (isApplying) "APLICANDO..." else "APLICAR CONFIGURAÇÕES",
          color = DarkCyberBg,
          fontSize = 15.sp,
          fontWeight = FontWeight.Black,
          fontFamily = FontFamily.Monospace,
          letterSpacing = 1.5.sp
        )
      }
    }

    Spacer(modifier = Modifier.height(10.dp))

    // Footer Security Notice
    Row(
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.Center
    ) {
      Icon(
        imageVector = Icons.Filled.Security,
        contentDescription = null,
        tint = TextMuted,
        modifier = Modifier.size(12.dp)
      )
      Spacer(modifier = Modifier.width(6.dp))
      Text(
        text = "MODO OVERLAY SEGURO • ANTI-BAN BYPASS 100% INDETECTÁVEL",
        color = TextMuted,
        fontSize = 9.sp,
        fontFamily = FontFamily.Monospace
      )
    }
  }
}
